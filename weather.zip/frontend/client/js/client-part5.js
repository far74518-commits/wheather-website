window.addEventListener('DOMContentLoaded', init);
